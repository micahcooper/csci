<html>
    <head>
	<link rel="stylesheet" href="http://www.cs.uga.edu/~cooper/4300/assn7/movie.css">
    <head>

    <body>
	<table class=nav>
	    <tr>
		<td><a href='movie.php' target='main'>Search Movies</a></td>
		<td><a href='add.php' target='main'>Add a Review</a></td>
		<td><a href='add.php?simple=1' target='main'>Add a Movie</a></td>
		<td></td>
		<td><a href='login.php' target='main'>Login</a></td>
		<td><a href='login.php?clear=1' target='main'>Logout</a></td>

	    </tr>
	</table>	
    </body>
</html>
